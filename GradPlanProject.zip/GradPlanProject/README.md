CS 246 Group Project for the Grad Plan app.
