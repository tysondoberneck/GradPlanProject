package com.example.gradplanproject;

import org.junit.Test;

public class TestFiltering {
    @Test
    public void testFilter() {
        //Test searching activity and dependencies
    }
}
