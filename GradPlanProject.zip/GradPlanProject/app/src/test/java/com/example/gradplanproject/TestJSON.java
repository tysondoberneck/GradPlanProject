package com.example.gradplanproject;

import org.junit.Test;

public class TestJSON {
    @Test
    public void testClass() {
        // test loading from LoadCoarseList class
    }
}
