package com.example.gradplanproject;

import org.junit.Test;

public class TestConnections {
    @Test
    public void testInternet() {

    }
    @Test
    public void testAPICall() {

    }
}
